#include "ht1621_772.h"

HT1621_772::HT1621_772(uint8_t csPin, uint8_t wrPin, uint8_t dataPin, uint8_t backlightPin) 
    : _csPin(csPin), _wrPin(wrPin), _dataPin(dataPin), _backlightPin(backlightPin) {}

void HT1621_772::begin() {
    pinMode(_csPin, OUTPUT);
    pinMode(_wrPin, OUTPUT);
    pinMode(_dataPin, OUTPUT);
    pinMode(_backlightPin, OUTPUT);

    digitalWrite(_backlightPin, HIGH);
    digitalWrite(_csPin, HIGH);

    reset();
    clearDisplay(16);
}

void HT1621_772::reset() {
    wrCMD(0x52);
    wrCMD(0x30);
    wrCMD(0x00);
    wrCMD(0x0A);
    wrCMD(0x02);
    wrCMD(0x06);
    wrCMD(0x04);
    wrCMD(0x06);
}

void HT1621_772::clearDisplay(uint8_t len) {
    uint8_t addr = 0;
    for (uint8_t i = 0; i < len; i++) {
        wrclrdata(addr, 0x00);
        addr++;
    }
}

void HT1621_772::displayNumber(int number) {
    int digits[6] = { 0, 0, 0, 0, 0, 0 };
    for (int i = 5; i >= 0; i--) {
        digits[i] = number % 10;
        number /= 10;
    }

    for (int i = 0; i < 6; i++) {
        wrclrdata(addressPairs[i][0], segmentCodes[digits[i]][0]);
        wrclrdata(addressPairs[i][1], segmentCodes[digits[i]][1]);
    }
}

void HT1621_772::wrCMD(uint8_t cmd) {
    digitalWrite(_csPin, LOW);
    wrDATA(0x80, 4);
    wrDATA(cmd, 8);
    digitalWrite(_csPin, HIGH);
}

void HT1621_772::wrDATA(uint8_t data, uint8_t cnt) {
    for (uint8_t i = 0; i < cnt; i++) {
        digitalWrite(_wrPin, LOW);
        delayMicroseconds(4);
        digitalWrite(_dataPin, (data & 0x80) ? HIGH : LOW);
        digitalWrite(_wrPin, HIGH);
        delayMicroseconds(4);
        data <<= 1;
    }
}

void HT1621_772::wrclrdata(uint8_t addr, uint8_t sdata) {
    addr <<= 2;
    digitalWrite(_csPin, LOW);
    wrDATA(0xa0, 3);
    wrDATA(addr, 6);
    wrDATA(sdata, 4);
    delayMicroseconds(4);
    digitalWrite(_csPin, HIGH);
}
