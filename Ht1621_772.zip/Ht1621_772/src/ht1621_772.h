#ifndef HT1621_772_H
#define HT1621_772_H

#include <Arduino.h>

class HT1621_772 {
public:
    HT1621_772(uint8_t csPin, uint8_t wrPin, uint8_t dataPin, uint8_t backlightPin);
    
    void begin();
    void clearDisplay(uint8_t len);
    void displayNumber(int number);
    void reset();

private:
    uint8_t _csPin;
    uint8_t _wrPin;
    uint8_t _dataPin;
    uint8_t _backlightPin;

    const uint8_t segmentCodes[10][2] = {
        { 0b10110000, 0b11100000 },  // 0
        { 0b00000000, 0b01100000 },  // 1
        { 0b01110000, 0b11000000 },  // 2
        { 0b01010000, 0b11100000 },  // 3
        { 0b11000000, 0b01100000 },  // 4
        { 0b11010000, 0b10100000 },  // 5
        { 0b11110000, 0b10100000 },  // 6
        { 0b10000000, 0b11100000 },  // 7
        { 0b11110000, 0b11100000 },  // 8
        { 0b11010000, 0b11100000 }   // 9
    };

    const uint8_t addressPairs[6][2] = {
        { 0b00001000, 0b00001001 },  // First digit
        { 0b00001010, 0b00001011 },  // Second digit
        { 0b00001100, 0b00001101 },  // Third digit
        { 0b00001110, 0b00000111 },  // Fourth digit
        { 0b00000110, 0b00000101 },  // Fifth digit
        { 0b00000100, 0b00000011 }   // Last digit
    };

    void wrCMD(uint8_t cmd);
    void wrDATA(uint8_t data, uint8_t cnt);
    void wrclrdata(uint8_t addr, uint8_t sdata);
};

#endif
